# Movie-Recommendation-System-Using-Python
 In this python project where using Pandas library we will find correlation and created basic Movie Recommender System with Python.
 
It is an extension from the project: https://github.com/krishnaik06/Movie-Recommender-in-python

The Dataset used is a subset of MovieLens Dataset.

### Extension
Have created a text input bar to add your movie whose recommendation you want. Output will give you top 4 matches that are recommended movies.

### Results
![Screen Shot 2020-06-06 at 9 36 16 PM](https://user-images.githubusercontent.com/15246084/83949017-fdefa080-a83e-11ea-9b21-9c278a8dea45.png)
![Screen Shot 2020-06-06 at 9 36 41 PM](https://user-images.githubusercontent.com/15246084/83949019-ffb96400-a83e-11ea-9607-3d1dbf5c3769.png)
